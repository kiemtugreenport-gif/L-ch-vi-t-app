# Lịch Việt
Lịch âm, nhắc mùng 1 và rằm, sự kiện, xem ngày tốt xấu, widget đồng hồ lật.
Đẩy code lên GitHub, vào tab Actions, chạy "Build APK", tải file lich-viet-apk.
Thư mục native/ chứa widget (Kotlin) và script vá dự án Android.
