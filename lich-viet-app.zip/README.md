# Lịch Việt
Lịch âm, nhắc mùng 1 và rằm, sự kiện, xem ngày tốt xấu, widget đồng hồ lật.
Đẩy code lên GitHub, vào tab Actions, chạy "Build APK", tải file lich-viet-apk.
Thư mục native/ chứa widget (Kotlin) và script vá dự án Android.

## Tab Widget
Mỗi bộ widget có một tab riêng (hiện có: Đồng hồ lật), cộng thêm tab Giao diện app.
Mỗi bộ widget có cài đặt riêng: kiểu giao diện, màu chữ số, kích thước, cỡ chữ.
Cài đặt lưu theo mã bộ widget (Config.SET_FLIP = "flip"), muốn thêm bộ mới thì thêm mã mới và một mục trong WGS ở www/index.html.
