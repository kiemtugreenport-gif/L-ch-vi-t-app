package com.lichviet.app

import android.content.Context

/** Thành phố do người dùng chọn trong màn hình cài đặt (mặc định: Hà Nội). */
object Config {
    const val WEATHER_REFRESH_MS = 30 * 60 * 1000L
    const val SET_FLIP = "flip"   // mã của bộ widget đồng hồ lật; mỗi bộ widget có cài đặt riêng theo mã
    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", 0)
    fun city(ctx: Context): String = p(ctx).getString("city", "Hà Nội") ?: "Hà Nội"
    fun lat(ctx: Context): Double = (p(ctx).getString("lat", "21.0285") ?: "21.0285").toDouble()
    fun lon(ctx: Context): Double = (p(ctx).getString("lon", "105.8542") ?: "105.8542").toDouble()
    fun style(ctx: Context): Int = p(ctx).getInt("style", 0)
    fun saveStyle(ctx: Context, i: Int) { p(ctx).edit().putInt("style", i).apply() }
    /** Kích thước nội dung widget, 50 đến 100 phần trăm (widget không thể vẽ lớn hơn khung của nó). */
    fun sizePct(ctx: Context, id: String): Int = p(ctx).getInt("size_$id", 100).coerceIn(50, 100)
    fun digitPct(ctx: Context, id: String): Int = p(ctx).getInt("digit_$id", 100).coerceIn(70, 105)
    fun textPct(ctx: Context, id: String): Int = p(ctx).getInt("text_$id", 100).coerceIn(80, 120)
    /** Màu chữ số dạng 0xAARRGGBB; 0 nghĩa là dùng màu của kiểu giao diện. */
    fun digitColor(ctx: Context, id: String): Int = p(ctx).getInt("dcol_$id", 0)
    fun saveSize(ctx: Context, id: String, v: Int) { p(ctx).edit().putInt("size_$id", v.coerceIn(50, 100)).apply() }
    fun saveDigitPct(ctx: Context, id: String, v: Int) { p(ctx).edit().putInt("digit_$id", v.coerceIn(70, 105)).apply() }
    fun saveTextPct(ctx: Context, id: String, v: Int) { p(ctx).edit().putInt("text_$id", v.coerceIn(80, 120)).apply() }
    fun saveDigitColor(ctx: Context, id: String, c: Int) { p(ctx).edit().putInt("dcol_$id", c).apply() }
    fun save(ctx: Context, city: String, lat: Double, lon: Double) {
        p(ctx).edit().putString("city", city).putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
        ctx.getSharedPreferences("weather", 0).edit().clear().apply() // bỏ thời tiết của thành phố cũ
    }
}
