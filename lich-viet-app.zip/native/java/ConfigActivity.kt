package com.lichviet.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/** Màn hình cài đặt widget đồng hồ lật: kiểu giao diện, màu số, kích thước, cỡ chữ, thành phố. */
class ConfigActivity : Activity() {
    private class Place(val name: String, val label: String, val lat: Double, val lon: Double)
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val widgetSet = Config.SET_FLIP

    /** Báo cho widget vẽ lại. Widget có màn hình cài đặt thì Android không tự cập nhật lần đầu. */
    private fun push() {
        sendBroadcast(Intent(this, ClockWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE))
    }
    private fun ok() {
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
    }

    override fun onPause() {
        super.onPause()
        push()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))

        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, px(16), 0, px(4)); textSize = 16f }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(px(20), px(48), px(20), px(24)) }
        root.addView(TextView(this).apply { text = "Cài đặt widget đồng hồ lật"; textSize = 22f })

        // Kiểu giao diện
        root.addView(label("Kiểu giao diện"))
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        Renderer.THEMES.forEachIndexed { i, t ->
            group.addView(RadioButton(this).apply { id = 1000 + i; text = t.name; isChecked = i == Config.style(this@ConfigActivity) })
        }
        group.setOnCheckedChangeListener { _, id ->
            Config.saveStyle(this, id - 1000)
            ok(); push()
        }
        root.addView(group)

        // Màu chữ số
        root.addView(label("Màu chữ số"))
        val colorName = TextView(this)
        fun colorText(c: Int) {
            colorName.text = if (c == 0) "Đang dùng: theo kiểu giao diện" else String.format("Đang dùng: #%06X", c and 0xFFFFFF)
        }
        colorText(Config.digitColor(this, widgetSet))
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val presets = listOf(0, 0xFFFFFFFF.toInt(), 0xFF111114.toInt(), 0xFFFFD54A.toInt(), 0xFFFF9F43.toInt(), 0xFFFF5C5C.toInt(),
            0xFFFF7EB6.toInt(), 0xFF7CF29C.toInt(), 0xFF4DD0E1.toInt(), 0xFF6AA9FF.toInt(), 0xFFB39DFF.toInt())
        presets.forEach { col ->
            swatches.addView(TextView(this).apply {
                gravity = Gravity.CENTER
                text = if (col == 0) "A" else ""
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (col == 0) Color.LTGRAY else col)
                    setStroke(px(2), 0x66000000)
                }
                layoutParams = LinearLayout.LayoutParams(px(38), px(38)).apply { rightMargin = px(8) }
                setOnClickListener {
                    Config.saveDigitColor(this@ConfigActivity, widgetSet, col)
                    colorText(col); ok(); push()
                }
            })
        }
        root.addView(HorizontalScrollView(this).apply { addView(swatches) })
        root.addView(colorName)
        val hex = EditText(this).apply {
            hint = "Hoặc nhập mã màu, ví dụ #FFD54A"; inputType = InputType.TYPE_CLASS_TEXT; setSingleLine()
        }
        root.addView(hex)
        root.addView(Button(this).apply {
            text = "Dùng mã màu này"
            setOnClickListener {
                val s = hex.text.toString().trim()
                val parsed = runCatching { Color.parseColor(if (s.startsWith("#")) s else "#$s") }.getOrNull()
                if (parsed == null) {
                    colorName.text = "Mã màu không hợp lệ"
                } else {
                    val col = parsed or 0xFF000000.toInt()
                    Config.saveDigitColor(this@ConfigActivity, widgetSet, col)
                    colorText(col); ok(); push()
                }
            }
        })

        // Kích thước và cỡ chữ
        fun slider(title: String, lo: Int, hi: Int, cur: Int, onSave: (Int) -> Unit) {
            val t = TextView(this).apply { text = "$title: $cur%"; setPadding(0, px(14), 0, 0) }
            val sb = SeekBar(this).apply {
                max = hi - lo
                progress = cur - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { t.text = "$title: ${p + lo}%" }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        onSave((s?.progress ?: 0) + lo)
                        ok(); push()
                    }
                })
            }
            root.addView(t); root.addView(sb)
        }
        root.addView(label("Kích thước và cỡ chữ"))
        slider("Kích thước widget", 50, 100, Config.sizePct(this, widgetSet)) { Config.saveSize(this, widgetSet, it) }
        slider("Cỡ chữ số đồng hồ", 70, 105, Config.digitPct(this, widgetSet)) { Config.saveDigitPct(this, widgetSet, it) }
        slider("Cỡ chữ ngày, âm lịch, thời tiết", 80, 120, Config.textPct(this, widgetSet)) { Config.saveTextPct(this, widgetSet, it) }

        // Thành phố thời tiết
        root.addView(label("Thành phố thời tiết"))
        root.addView(TextView(this).apply { text = "Đang dùng: ${Config.city(this@ConfigActivity)}" })
        val input = EditText(this).apply {
            hint = "Nhập tên thành phố, ví dụ: Đà Nẵng"; inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH; setSingleLine()
        }
        val btn = Button(this).apply { text = "Tìm" }
        val status = TextView(this).apply { setPadding(0, px(8), 0, px(8)) }
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(input); root.addView(btn); root.addView(status); root.addView(results)

        root.addView(Button(this).apply {
            text = "Xong"
            setOnClickListener { ok(); push(); finish() }
        })
        setContentView(ScrollView(this).apply { addView(root) })

        fun search() {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return
            status.text = "Đang tìm…"
            thread {
                val found = mutableListOf<Place>()
                var err: String? = null
                try {
                    val u = "https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(q, "UTF-8")}&count=8&language=vi"
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 6000; c.readTimeout = 6000
                    val arr = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("results")
                    for (i in 0 until (arr?.length() ?: 0)) {
                        val o = arr!!.getJSONObject(i)
                        val name = o.getString("name")
                        val lbl = listOf(name, o.optString("admin1"), o.optString("country")).filter { it.isNotBlank() }.joinToString(", ")
                        found.add(Place(name, lbl, o.getDouble("latitude"), o.getDouble("longitude")))
                    }
                } catch (e: Exception) { err = "Không kết nối được. Kiểm tra mạng rồi thử lại." }
                runOnUiThread {
                    results.removeAllViews()
                    found.forEach { p ->
                        results.addView(TextView(this).apply {
                            text = p.label; textSize = 16f; setPadding(px(4), px(12), px(4), px(12))
                            setOnClickListener {
                                Config.save(this@ConfigActivity, p.name, p.lat, p.lon)
                                ok(); push(); finish()
                            }
                        })
                    }
                    status.text = err ?: if (found.isEmpty()) "Không tìm thấy. Thử tên khác hoặc viết không dấu." else "Chạm vào kết quả để chọn:"
                }
            }
        }
        btn.setOnClickListener { search() }
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false }
    }
}
