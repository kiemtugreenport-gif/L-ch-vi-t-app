package com.lichviet.app

import kotlin.math.*

/** Đổi dương lịch sang âm lịch Việt Nam (thuật toán Hồ Ngọc Đức, múi giờ +7). */
object Lunar {
    data class Date(val d: Int, val m: Int, val y: Int, val leap: Boolean)
    private const val TZ = 7.0
    private const val SYN = 29.530588853
    private const val EPOCH = 2415021.076998695
    val CAN = listOf("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý")
    val CHI = listOf("Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi")
    fun yearName(y: Int) = "${CAN[(y + 6) % 10]} ${CHI[(y + 8) % 12]}"

    private fun jd(d: Int, m: Int, y: Int): Int {
        val a = (14 - m) / 12; val yy = y + 4800 - a; val mm = m + 12 * a - 3
        return d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - yy / 100 + yy / 400 - 32045
    }
    private fun newMoon(k: Int): Int {
        val T = k / 1236.85; val T2 = T * T; val T3 = T2 * T; val r = PI / 180
        var J = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3
        J += 0.00033 * sin((166.56 + 132.87 * T - 0.009173 * T2) * r)
        val M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3
        val Mp = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3
        val F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3
        var C = (0.1734 - 0.000393 * T) * sin(M * r) + 0.0021 * sin(2 * r * M)
        C -= 0.4068 * sin(Mp * r)
        C += 0.0161 * sin(r * 2 * Mp)
        C -= 0.0004 * sin(r * 3 * Mp)
        C += 0.0104 * sin(r * 2 * F) - 0.0051 * sin(r * (M + Mp))
        C -= 0.0074 * sin(r * (M - Mp))
        C += 0.0004 * sin(r * (2 * F + M))
        C -= 0.0004 * sin(r * (2 * F - M))
        C -= 0.0006 * sin(r * (2 * F + Mp))
        C += 0.001 * sin(r * (2 * F - Mp)) + 0.0005 * sin(r * (2 * Mp + M))
        val dt = if (T < -11) 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3
        else -0.000278 + 0.000265 * T + 0.000262 * T2
        return floor(J + C - dt + 0.5 + TZ / 24).toInt()
    }
    private fun sunLong(n: Int): Int {
        val T = (n - 2451545.5 - TZ / 24) / 36525; val T2 = T * T; val r = PI / 180
        val M = 357.5291 + 35999.0503 * T - 0.0001559 * T2 - 0.00000048 * T * T2
        val L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2
        val D = (1.9146 - 0.004817 * T - 0.000014 * T2) * sin(r * M) +
                (0.019993 - 0.000101 * T) * sin(r * 2 * M) + 0.00029 * sin(r * 3 * M)
        var L = (L0 + D) * r
        L -= PI * 2 * floor(L / (PI * 2))
        return floor(L / PI * 6).toInt()
    }
    private fun month11(y: Int): Int {
        val k = floor((jd(31, 12, y) - 2415021) / SYN).toInt()
        var nm = newMoon(k)
        if (sunLong(nm) >= 9) nm = newMoon(k - 1)
        return nm
    }
    private fun leapOffset(a11: Int): Int {
        val k = floor((a11 - EPOCH) / SYN + 0.5).toInt()
        var i = 1; var last: Int; var arc = sunLong(newMoon(k + i))
        do { last = arc; i++; arc = sunLong(newMoon(k + i)) } while (arc != last && i < 14)
        return i - 1
    }
    fun convert(dd: Int, mm: Int, yy: Int): Date {
        val dn = jd(dd, mm, yy)
        val k = floor((dn - EPOCH) / SYN).toInt()
        var ms = newMoon(k + 1)
        if (ms > dn) ms = newMoon(k)
        var a11 = month11(yy); var b11 = a11; var ly: Int
        if (a11 >= ms) { ly = yy; a11 = month11(yy - 1) } else { ly = yy + 1; b11 = month11(yy + 1) }
        val ld = dn - ms + 1
        val diff = (ms - a11) / 29
        var leap = false; var lm = diff + 11
        if (b11 - a11 > 365) {
            val lo = leapOffset(a11)
            if (diff >= lo) { lm = diff + 10; if (diff == lo) leap = true }
        }
        if (lm > 12) lm -= 12
        if (lm >= 11 && diff < 4) ly -= 1
        return Date(ld, lm, ly, leap)
    }
}
