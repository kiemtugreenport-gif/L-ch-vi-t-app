package com.lichviet.app

import android.content.Context
import android.graphics.*
import android.text.format.DateFormat
import java.util.Calendar
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos

/** Bộ màu cho từng kiểu giao diện. Màu dạng 0xAARRGGBB. */
data class Theme(
    val name: String,
    val topA: Long, val topB: Long, val botA: Long, val botB: Long, val digit: Long,
    val rim: Long, val rimW: Float,
    val solid: Boolean, val grain: Boolean, val liquid: Boolean,
    val panelA: Long, val panelB: Long, val panelRim: Long,
    val text: Long, val dim: Long, val accent: Long,
    val hinge: Long, val pivot: Long, val ampm: Long, val moonDark: Long, val tshadow: Boolean
)

/** Hệ số cỡ chữ: digit cho số đồng hồ, text cho các dòng ngày, âm lịch, thời tiết. */
class Opts(val digit: Float, val text: Float)

/** Trạng thái lật: số cũ của giờ/phút và tiến độ p từ 0 đến 1. */
class Anim(val oldH: String, val oldM: String, val p: Float)

/** Vẽ toàn bộ widget thành một ảnh bitmap. */
object Renderer {
    fun timeStrings(ctx: Context, cal: Calendar = Calendar.getInstance()): Pair<String, String> {
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val hh = if (DateFormat.is24HourFormat(ctx)) h24 else (h24 % 12).let { if (it == 0) 12 else it }
        return "%02d".format(hh) to "%02d".format(cal.get(Calendar.MINUTE))
    }

    val THEMES = listOf(
        Theme("Cổ điển", 0xFFFDFDFF, 0xFFEBEBF1, 0xFFDCDCE5, 0xFFF6F6FA, 0xFF1A1826, 0, 0f, true, false, false,
            0xCC2A2545, 0xCC141228, 0x26FFFFFF, 0xFFF5F3FC, 0xFFB4AFCC, 0xFFA99BFF, 0x4D141228, 0xFF77758A, 0xFF6A6880, 0xFF0B0916, false),
        Theme("Tối", 0xFF2C2942, 0xFF222036, 0xFF1B1930, 0xFF25223A, 0xFFF2F0FA, 0x1AFFFFFF, 2f, true, false, false,
            0xE61C1A2E, 0xE6141228, 0x1FFFFFFF, 0xFFF5F3FC, 0xFFA6A1C2, 0xFFA99BFF, 0x80000000, 0xFF14122A, 0xFF8C88A8, 0xFF0B0916, false),
        Theme("Trong suốt", 0x0DFFFFFF, 0x0DFFFFFF, 0x0DFFFFFF, 0x0DFFFFFF, 0xFFFFFFFF, 0x99FFFFFF, 2.5f, false, false, false,
            0x00000000, 0x00000000, 0x66FFFFFF, 0xFFFFFFFF, 0xE6FFFFFF, 0xFFFFFFFF, 0x66FFFFFF, 0x99FFFFFF, 0xCCFFFFFF, 0x990B0916, true),
        Theme("Kính mờ", 0x73FFFFFF, 0x5CFFFFFF, 0x4DFFFFFF, 0x38FFFFFF, 0xFFFFFFFF, 0x66FFFFFF, 2f, false, true, false,
            0x47FFFFFF, 0x2EFFFFFF, 0x59FFFFFF, 0xFFFFFFFF, 0xE6FFFFFF, 0xFFFFFFFF, 0x59FFFFFF, 0x99FFFFFF, 0xE6FFFFFF, 0xFF0B0916, true),
        Theme("Kính lỏng", 0x45FFFFFF, 0x24FFFFFF, 0x1CFFFFFF, 0x2EFFFFFF, 0xFFFFFFFF, 0, 0f, false, false, true,
            0x33FFFFFF, 0x12FFFFFF, 0, 0xFFFFFFFF, 0xE6FFFFFF, 0xFFFFFFFF, 0x59FFFFFF, 0x80FFFFFF, 0xE6FFFFFF, 0xE60B0916, true)
    )

    private val Long.i get() = this.toInt()
    private const val W = 800
    private const val H = 512
    private const val PAD = 10f
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val reg = Typeface.create("sans-serif", Typeface.NORMAL)
    private val med = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val THU = listOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")

    private fun paint(t: Theme, size: Float, color: Long, tf: Typeface = reg, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color.i; typeface = tf; textAlign = align
            if (t.tshadow) setShadowLayer(8f, 0f, 2f, 0x66000000)
        }

    fun render(ctx: Context, w: Weather?, anim: Anim? = null): Bitmap {
        val base = THEMES[Config.style(ctx).coerceIn(0, THEMES.lastIndex)]
        val wid = Config.SET_FLIP
        val dc = Config.digitColor(ctx, wid)
        val t = if (dc != 0) base.copy(digit = dc.toLong() and 0xFFFFFFFFL) else base   // màu số do người dùng chọn
        val o = Opts(Config.digitPct(ctx, wid) / 100f, Config.textPct(ctx, wid) / 100f)
        val sz = Config.sizePct(ctx, wid) / 100f
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.save()
        c.translate(W * (1 - sz) / 2f, H * (1 - sz) / 2f)   // thu nhỏ nội dung về giữa khung
        c.scale(sz, sz)
        val now = Calendar.getInstance()
        val h24 = now.get(Calendar.HOUR_OF_DAY)
        val is24 = DateFormat.is24HourFormat(ctx)
        val (hs, ms) = timeStrings(ctx, now)
        val cardW = (W - 2 * PAD - 16) / 2; val cardH = 260f
        card(c, t, PAD, PAD, cardW, cardH, hs, anim?.takeIf { it.oldH != hs }?.let { it.oldH to it.p },
            if (is24) null else if (h24 >= 12) "PM" else "AM", o)
        card(c, t, PAD + cardW + 16, PAD, cardW, cardH, ms, anim?.takeIf { it.oldM != ms }?.let { it.oldM to it.p }, null, o)

        val top = PAD + cardH + 24; val bottom = H - PAD
        val panel = RectF(PAD, top, W - PAD, bottom)
        val pr = if (t.liquid) 44f else 34f
        if (t.panelA != 0L || t.panelB != 0L)
            c.drawRoundRect(panel, pr, pr, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, top, 0f, bottom, t.panelA.i, t.panelB.i, Shader.TileMode.CLAMP) })
        if (t.liquid) gloss(c, panel, pr)
        rim(c, panel, pr, t.panelRim, t.liquid, 2f)

        val lunar = Lunar.convert(now.get(Calendar.DAY_OF_MONTH), now.get(Calendar.MONTH) + 1, now.get(Calendar.YEAR))
        val lx = PAD + 40
        c.drawText("%s, %02d/%02d".format(THU[now.get(Calendar.DAY_OF_WEEK) - 1], now.get(Calendar.DAY_OF_MONTH), now.get(Calendar.MONTH) + 1),
            lx, top + 76, paint(t, 34f * o.text, t.text, med))
        c.drawText("Âm lịch ${lunar.d}/${lunar.m}${if (lunar.leap) " nhuận" else ""}", lx, top + 120, paint(t, 28f * o.text, t.dim))
        c.drawText("Năm ${Lunar.yearName(lunar.y)}", lx, top + 156, paint(t, 28f * o.text, t.accent))

        val rx = W - PAD - 40
        c.drawText(Config.city(ctx), rx, top + 52, paint(t, 26f * o.text, t.dim, reg, Paint.Align.RIGHT))
        if (w != null) {
            c.drawText("${w.temp}°", rx, top + 126, paint(t, 78f * o.text, t.text, light, Paint.Align.RIGHT))
            c.drawText(w.text, rx, top + 164, paint(t, 28f * o.text, t.dim, reg, Paint.Align.RIGHT))
            c.drawText("${w.hi}° / ${w.lo}°", rx, top + 196, paint(t, 26f * o.text, t.dim, reg, Paint.Align.RIGHT))
        } else c.drawText("Đang tải…", rx, top + 126, paint(t, 30f * o.text, t.dim, reg, Paint.Align.RIGHT))

        WeatherIcon.draw(c, W / 2f, top - 6, w?.code ?: 0, w?.isDay ?: (h24 in 6..17), lunar.d, t.moonDark.i)
        c.restore()
        return bmp
    }

    /** Viền kính: kính lỏng dùng viền chuyển sáng-tối chéo như ánh sáng bắt vào mép kính. */
    private fun rim(c: Canvas, rc: RectF, r: Float, col: Long, liquid: Boolean, wd: Float) {
        val sw = if (liquid) 3f else wd
        if (sw <= 0f || (!liquid && col == 0L)) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = sw
            if (liquid) shader = LinearGradient(rc.left, rc.top, rc.right, rc.bottom,
                intArrayOf(0xE6FFFFFF.toInt(), 0x26FFFFFF, 0x26FFFFFF, 0xBFFFFFFF.toInt()), floatArrayOf(0f, .35f, .65f, 1f), Shader.TileMode.CLAMP)
            else color = col.i
        }
        val h = sw / 2
        c.drawRoundRect(RectF(rc.left + h, rc.top + h, rc.right - h, rc.bottom - h), r, r, p)
    }

    /** Ánh bóng phía trên, ánh sáng đáy và sắc xanh-tím nhẹ của kính lỏng. */
    private fun gloss(c: Canvas, rc: RectF, r: Float) {
        c.save(); c.clipPath(Path().apply { addRoundRect(rc, r, r, Path.Direction.CW) })
        val tm = rc.top + rc.height() * .5f; val bt = rc.bottom - rc.height() * .18f
        c.drawRect(rc, Paint().apply { shader = LinearGradient(rc.left, rc.top, rc.right, rc.bottom, 0x1F5AA9FF, 0x1FB07CFF, Shader.TileMode.CLAMP) })
        c.drawRect(rc.left, rc.top, rc.right, tm, Paint().apply { shader = LinearGradient(0f, rc.top, 0f, tm, 0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP) })
        c.drawRect(rc.left, bt, rc.right, rc.bottom, Paint().apply { shader = LinearGradient(0f, bt, 0f, rc.bottom, 0x00FFFFFF, 0x2EFFFFFF, Shader.TileMode.CLAMP) })
        c.restore()
    }

    /** Vẽ một nửa thẻ (trên hoặc dưới) cùng phần số nằm trong nửa đó. */
    private fun half(c: Canvas, t: Theme, x: Float, y: Float, w: Float, h: Float, r: Float, top: Boolean, digits: String, o: Opts) {
        val mid = y + h / 2
        val rr = if (top) floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) else floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        val a = if (top) y else mid; val b = if (top) mid else y + h
        val p = Path().apply { addRoundRect(RectF(x, a, x + w, b), rr, Path.Direction.CW) }
        val c0 = if (top) t.topA else t.botA; val c1 = if (top) t.topB else t.botB
        c.drawPath(p, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(0f, a, 0f, b, c0.i, c1.i, Shader.TileMode.CLAMP) })
        c.save(); c.clipPath(p)
        if (t.grain) { // hạt mịn cho kính mờ
            val rnd = Random(if (top) 7 else 8); val pts = FloatArray(450)
            for (i in 0 until 225) { pts[i * 2] = x + rnd.nextFloat() * w; pts[i * 2 + 1] = a + rnd.nextFloat() * (b - a) }
            c.drawPoints(pts, Paint().apply { color = 0x1AFFFFFF; strokeWidth = 2.2f; strokeCap = Paint.Cap.ROUND })
        }
        val tp = paint(t, 330f * o.digit, t.digit, light, Paint.Align.CENTER).apply { letterSpacing = -0.03f }
        val bb = Rect(); tp.getTextBounds(digits, 0, digits.length, bb)
        c.drawText(digits, x + w / 2, mid - bb.exactCenterY(), tp)
        c.restore()
    }

    private fun shade(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float, top: Boolean, alpha: Float) {
        val rr = if (top) floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) else floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        val a = if (top) y else y + h / 2; val b = if (top) y + h / 2 else y + h
        c.drawPath(Path().apply { addRoundRect(RectF(x, a, x + w, b), rr, Path.Direction.CW) },
            Paint().apply { color = Color.argb((255 * alpha).toInt().coerceIn(0, 255), 0, 0, 0) })
    }

    /** flip = (số cũ, tiến độ 0..1). Nửa trên gập xuống rồi nửa dưới lật lên như thẻ đồng hồ lật thật. */
    private fun card(c: Canvas, t: Theme, x: Float, y: Float, w: Float, h: Float, digits: String, flip: Pair<String, Float>?, ampm: String?, o: Opts) {
        val r = if (t.liquid) 36f else 24f; val mid = y + h / 2
        val full = RectF(x, y, x + w, y + h)
        if (t.solid) {
            c.drawRoundRect(RectF(x + 16, y + 12, x + w - 16, y + h + 14), r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.pivot.i })
            c.drawRoundRect(full, r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.botB.i; setShadowLayer(18f, 0f, 8f, 0x66000000) })
        }
        val oldD = flip?.first; val p = flip?.second
        half(c, t, x, y, w, h, r, true, digits, o)            // nửa trên: số mới nằm sẵn bên dưới tấm lật
        half(c, t, x, y, w, h, r, false, oldD ?: digits, o)    // nửa dưới: số cũ cho tới khi tấm mới rơi xuống
        if (t.liquid) gloss(c, full, r)
        if (p != null && oldD != null) {
            c.save()
            if (p < 0.5f) {
                c.scale(1f, cos(p * Math.PI).toFloat().coerceAtLeast(0.001f), x, mid)
                half(c, t, x, y, w, h, r, true, oldD, o)
                shade(c, x, y, w, h, r, true, p * 0.8f)
            } else {
                c.scale(1f, (-cos(p * Math.PI)).toFloat().coerceAtLeast(0.001f), x, mid)
                half(c, t, x, y, w, h, r, false, digits, o)
                shade(c, x, y, w, h, r, false, (1f - p) * 0.8f)
            }
            c.restore()
        }
        c.drawRect(x + (if (t.liquid) 18f else 0f), mid - 2, x + w - (if (t.liquid) 18f else 0f), mid + 2, Paint().apply { color = t.hinge.i })
        val pv = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.pivot.i }
        c.drawRoundRect(RectF(x - 4, mid - 14, x + 10, mid + 14), 6f, 6f, pv)
        c.drawRoundRect(RectF(x + w - 10, mid - 14, x + w + 4, mid + 14), 6f, 6f, pv)
        rim(c, full, r, t.rim, t.liquid, t.rimW)
        if (ampm != null) c.drawText(ampm, x + 26, y + h - 24, paint(t, 28f, t.ampm, med).apply { letterSpacing = 0.05f })
    }
}
