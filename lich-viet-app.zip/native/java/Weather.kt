package com.lichviet.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Weather(val temp: Int, val hi: Int, val lo: Int, val code: Int, val ts: Long, val isDay: Boolean = true) {
    val text get() = when (code) {
        0 -> "Trời quang"; 1, 2 -> "Ít mây"; 3 -> "Nhiều mây"; 45, 48 -> "Sương mù"
        in 51..57 -> "Mưa phùn"; in 61..67 -> "Mưa"; in 71..77 -> "Tuyết"
        in 80..82 -> "Mưa rào"; in 95..99 -> "Dông"; else -> "Có mây"
    }
    val icon get() = when (code) {
        0 -> "☀️"; 1, 2 -> "🌤️"; 3 -> "☁️"; 45, 48 -> "🌫️"; in 51..57 -> "🌦️"
        in 61..67, in 80..82 -> "🌧️"; in 71..77 -> "❄️"; in 95..99 -> "⛈️"; else -> "☁️"
    }

    companion object {
        private const val PREF = "weather"
        private const val RETRY_MS = 5 * 60 * 1000L
        fun cached(ctx: Context): Weather? {
            val s = ctx.getSharedPreferences(PREF, 0).getString("json", null) ?: return null
            return runCatching { JSONObject(s).let {
                Weather(it.getInt("t"), it.getInt("h"), it.getInt("l"), it.getInt("c"), it.getLong("ts"), it.optInt("d", 1) == 1)
            } }.getOrNull()
        }
        /** Lấy thời tiết từ Open-Meteo (miễn phí, không cần khoá API). */
        fun refreshIfStale(ctx: Context): Weather? {
            val old = cached(ctx)
            val now = System.currentTimeMillis()
            if (old != null && now - old.ts < Config.WEATHER_REFRESH_MS) return old
            val prefs = ctx.getSharedPreferences(PREF, 0)
            if (now - prefs.getLong("try", 0L) < RETRY_MS) return old   // vừa thử xong, chờ 5 phút rồi thử lại
            prefs.edit().putLong("try", now).apply()
            return runCatching {
                val u = "https://api.open-meteo.com/v1/forecast?latitude=${Config.lat(ctx)}&longitude=${Config.lon(ctx)}" +
                        "&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 5000
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
                val w = Weather(Math.round(cur.getDouble("temperature_2m")).toInt(),
                    Math.round(d.getJSONArray("temperature_2m_max").getDouble(0)).toInt(),
                    Math.round(d.getJSONArray("temperature_2m_min").getDouble(0)).toInt(),
                    cur.getInt("weather_code"), System.currentTimeMillis(), cur.optInt("is_day", 1) == 1)
                ctx.getSharedPreferences(PREF, 0).edit().putString("json",
                    JSONObject().put("t", w.temp).put("h", w.hi).put("l", w.lo).put("c", w.code).put("ts", w.ts).put("d", if (w.isDay) 1 else 0).toString()).apply()
                w
            }.getOrDefault(old)
        }
    }
}
