package com.lichviet.app

import android.graphics.*
import kotlin.math.*

/** Biểu tượng thời tiết vẽ bằng gradient, đổi theo mã thời tiết và ngày/đêm. */
object WeatherIcon {
    private fun p() = Paint(Paint.ANTI_ALIAS_FLAG)
    private val CRATERS = floatArrayOf(-0.35f, -0.25f, 0.22f, 0.3f, -0.4f, 0.15f, 0.1f, 0.25f, 0.26f,
        -0.4f, 0.35f, 0.12f, 0.45f, 0.1f, 0.13f, -0.05f, -0.55f, 0.1f)

    fun draw(c: Canvas, cx: Float, cy: Float, code: Int, isDay: Boolean, lunarDay: Int, moonDark: Int) {
        val r = 58f
        fun orb(x: Float, y: Float, rr: Float) { if (isDay) sun(c, x, y, rr) else moon(c, x, y, rr, lunarDay, moonDark) }
        when (code) {
            0 -> orb(cx, cy, r)
            1 -> { orb(cx - 20, cy - 16, r * .72f); cloud(c, cx + 16, cy + 20, 110f, isDay, false) }
            2 -> { orb(cx - 30, cy - 24, r * .6f); cloud(c, cx + 8, cy + 16, 135f, isDay, false) }
            3 -> { cloud(c, cx - 26, cy - 12, 105f, isDay, true); cloud(c, cx + 14, cy + 14, 130f, isDay, false) }
            45, 48 -> { cloud(c, cx, cy - 14, 130f, isDay, false); fog(c, cx, cy + 28) }
            in 51..57, in 61..67 -> { cloud(c, cx, cy - 14, 135f, isDay, true); rain(c, cx, cy + 30, 5) }
            in 80..82 -> { orb(cx - 34, cy - 30, r * .5f); cloud(c, cx + 4, cy - 10, 135f, isDay, true); rain(c, cx, cy + 32, 5) }
            in 71..77 -> { cloud(c, cx, cy - 14, 135f, isDay, false); snow(c, cx, cy + 34) }
            in 95..99 -> { cloud(c, cx, cy - 18, 140f, isDay, true); rain(c, cx, cy + 28, 4); bolt(c, cx + 2, cy + 18) }
            else -> cloud(c, cx, cy, 140f, isDay, false)
        }
    }

    private fun sun(c: Canvas, x: Float, y: Float, r: Float) {
        c.drawCircle(x, y, r * 2.3f, p().apply { shader = RadialGradient(x, y, r * 2.3f, intArrayOf(0x66FFD34D, 0x00FFD34D), null, Shader.TileMode.CLAMP) })
        val ray = p().apply { color = 0xE6FFC53D.toInt(); strokeWidth = r * .13f; strokeCap = Paint.Cap.ROUND }
        for (i in 0 until 12) {
            val a = i * PI / 6; val r0 = r * 1.22f; val r1 = r * (if (i % 2 == 0) 1.62f else 1.45f)
            c.drawLine(x + (cos(a) * r0).toFloat(), y + (sin(a) * r0).toFloat(), x + (cos(a) * r1).toFloat(), y + (sin(a) * r1).toFloat(), ray)
        }
        c.drawCircle(x, y, r, p().apply {
            shader = RadialGradient(x - r * .3f, y - r * .3f, r * 1.25f, intArrayOf(0xFFFFF6BF.toInt(), 0xFFFFC93C.toInt(), 0xFFFF8F1F.toInt()),
                floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
            setShadowLayer(r * .25f, 0f, 0f, 0x99FFB020.toInt())
        })
    }

    private fun moon(c: Canvas, x: Float, y: Float, r: Float, lunarDay: Int, dark: Int) {
        c.drawCircle(x, y, r * 2f, p().apply { shader = RadialGradient(x, y, r * 2f, intArrayOf(0x44BFD4FF, 0x00BFD4FF), null, Shader.TileMode.CLAMP) })
        c.save(); c.translate(x, y)
        c.drawCircle(0f, 0f, r, p().apply { color = dark })
        val ph = ((lunarDay - 1) % 29.53) / 29.53
        val wax = ph <= 0.5; val pp = if (wax) ph else 1 - ph
        val k = maxOf(abs(cos(2 * PI * pp)).toFloat() * r, 0.5f)
        if (!wax) c.scale(-1f, 1f)
        val lit = Path().apply {
            moveTo(0f, -r); arcTo(RectF(-r, -r, r, r), -90f, 180f)
            arcTo(RectF(-k, -r, k, r), 90f, if (pp < 0.25) -180f else 180f); close()
        }
        c.drawPath(lit, p().apply {
            shader = RadialGradient(-r * .2f, -r * .3f, r * 1.4f, intArrayOf(0xFFF4F3F8.toInt(), 0xFFC4C2CE.toInt(), 0xFF7F7D8C.toInt()),
                floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP) })
        c.save(); c.clipPath(lit)
        for (i in CRATERS.indices step 3) {
            val cr = CRATERS[i + 2] * r; val px = CRATERS[i] * r; val py = CRATERS[i + 1] * r
            c.drawCircle(px, py, cr, p().apply { shader = RadialGradient(px, py, cr, intArrayOf(0x55454A66, 0x00454A66), null, Shader.TileMode.CLAMP) })
        }
        c.restore(); c.restore()
        c.drawCircle(x, y, r, p().apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0x30FFFFFF })
    }

    private fun cloud(c: Canvas, x: Float, y: Float, w: Float, isDay: Boolean, dark: Boolean) {
        val u = w / 100f
        val path = Path().apply {
            addCircle(x - 26 * u, y + 6 * u, 20 * u, Path.Direction.CW); addCircle(x - 6 * u, y - 8 * u, 27 * u, Path.Direction.CW)
            addCircle(x + 20 * u, y, 22 * u, Path.Direction.CW); addCircle(x + 36 * u, y + 10 * u, 16 * u, Path.Direction.CW)
            addRoundRect(RectF(x - 46 * u, y + 2 * u, x + 52 * u, y + 26 * u), 12 * u, 12 * u, Path.Direction.CW)
        }
        val (t0, b0) = if (dark) { if (isDay) 0xFFB9C2D3 to 0xFF7E8AA2 else 0xFF8E98B4 to 0xFF59627F }
                       else { if (isDay) 0xFFFFFFFF to 0xFFD3DBE8 else 0xFFCBD2E8 to 0xFF8F99BA }
        c.drawPath(path, p().apply {
            shader = LinearGradient(0f, y - 35 * u, 0f, y + 28 * u, t0.toInt(), b0.toInt(), Shader.TileMode.CLAMP)
            setShadowLayer(10 * u, 0f, 5 * u, 0x55000000)
        })
    }

    private fun rain(c: Canvas, x: Float, y: Float, n: Int) {
        val d = p().apply { color = 0xFF7CC4FF.toInt(); strokeWidth = 5f; strokeCap = Paint.Cap.ROUND }
        for (i in 0 until n) { val dx = x - 40 + i * (80f / (n - 1)); val dy = y + (i % 2) * 10; c.drawLine(dx, dy, dx - 7, dy + 20, d) }
    }

    private fun snow(c: Canvas, x: Float, y: Float) {
        val s = p().apply { color = Color.WHITE; setShadowLayer(6f, 0f, 0f, 0xCCBFE3FF.toInt()) }
        for (i in 0 until 4) c.drawCircle(x - 36 + i * 24, y + (i % 2) * 14, 5f, s)
    }

    private fun bolt(c: Canvas, x: Float, y: Float) {
        val b = Path().apply {
            moveTo(x + 6, y); lineTo(x - 12, y + 28); lineTo(x - 1, y + 28); lineTo(x - 9, y + 54)
            lineTo(x + 16, y + 20); lineTo(x + 3, y + 20); lineTo(x + 12, y); close()
        }
        c.drawPath(b, p().apply { color = 0xFFFFD84A.toInt(); setShadowLayer(8f, 0f, 0f, 0xAAFFC400.toInt()) })
        c.drawPath(b, p().apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0xFFFFA800.toInt() })
    }

    private fun fog(c: Canvas, x: Float, y: Float) {
        val f = p().apply { color = 0xCCDDE3F0.toInt() }
        c.drawRoundRect(RectF(x - 50, y, x + 50, y + 8), 4f, 4f, f)
        c.drawRoundRect(RectF(x - 38, y + 14, x + 58, y + 22), 4f, 4f, f)
        c.drawRoundRect(RectF(x - 56, y + 28, x + 36, y + 36), 4f, 4f, f)
    }
}
