package com.lichviet.app;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "WidgetBridge")
public class WidgetPlugin extends Plugin {
    @PluginMethod
    public void openConfig(PluginCall call) {
        getActivity().startActivity(new Intent(getContext(), ConfigActivity.class));
        call.resolve();
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        AppWidgetManager m = AppWidgetManager.getInstance(getContext());
        if (m.isRequestPinAppWidgetSupported()) {
            m.requestPinAppWidget(new ComponentName(getContext(), ClockWidget.class), null, null);
            call.resolve();
        } else {
            call.reject("unsupported");
        }
    }

    /** Đọc cài đặt hiện tại của một bộ widget (mã bộ widget: "flip"). */
    @PluginMethod
    public void getSettings(PluginCall call) {
        String id = call.getString("set", Config.SET_FLIP);
        Context c = getContext();
        int col = Config.INSTANCE.digitColor(c, id);
        JSObject o = new JSObject();
        o.put("style", Config.INSTANCE.style(c));
        o.put("sizePct", Config.INSTANCE.sizePct(c, id));
        o.put("digitPct", Config.INSTANCE.digitPct(c, id));
        o.put("textPct", Config.INSTANCE.textPct(c, id));
        o.put("color", col == 0 ? "" : String.format("#%06X", col & 0xFFFFFF));
        call.resolve(o);
    }

    /** Lưu kiểu giao diện, kích thước, cỡ chữ, màu số rồi vẽ lại widget. */
    @PluginMethod
    public void saveSettings(PluginCall call) {
        String id = call.getString("set", Config.SET_FLIP);
        Context c = getContext();
        Config.INSTANCE.saveStyle(c, call.getInt("style", 0));
        Config.INSTANCE.saveSize(c, id, call.getInt("sizePct", 100));
        Config.INSTANCE.saveDigitPct(c, id, call.getInt("digitPct", 100));
        Config.INSTANCE.saveTextPct(c, id, call.getInt("textPct", 100));
        String hex = call.getString("color", "");
        int col = 0;
        if (hex != null && hex.length() == 7 && hex.charAt(0) == '#') {
            try {
                col = 0xFF000000 | Integer.parseInt(hex.substring(1), 16);
            } catch (Exception e) {
                col = 0;
            }
        }
        Config.INSTANCE.saveDigitColor(c, id, col);
        c.sendBroadcast(new Intent(c, ClockWidget.class).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE));
        call.resolve();
    }
}
