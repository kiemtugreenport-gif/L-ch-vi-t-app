package com.lichviet.app;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "WidgetBridge")
public class WidgetPlugin extends Plugin {
    @PluginMethod
    public void openConfig(PluginCall call) {
        getActivity().startActivity(new Intent(getContext(), ConfigActivity.class));
        call.resolve();
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        AppWidgetManager m = AppWidgetManager.getInstance(getContext());
        if (m.isRequestPinAppWidgetSupported()) {
            m.requestPinAppWidget(new ComponentName(getContext(), ClockWidget.class), null, null);
            call.resolve();
        } else {
            call.reject("unsupported");
        }
    }
}
