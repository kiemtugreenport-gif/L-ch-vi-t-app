import re, sys, pathlib
A = pathlib.Path('android')

def edit(path, fn):
    p = A / path
    s = p.read_text(encoding='utf-8')
    n = fn(s)
    if n == s:
        print('KHONG SUA DUOC:', path); sys.exit(1)
    p.write_text(n, encoding='utf-8')
    print('da vá', path)

# Kotlin cho build.gradle cấp gốc
edit('build.gradle', lambda s: s if 'kotlin-gradle-plugin' in s else re.sub(
    r"(classpath\s*['\"]com\.android\.tools\.build:gradle:[^'\"]+['\"])",
    r"\1\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.24'", s, count=1))

# Bật Kotlin trong module app
def app(s):
    if 'kotlin-android' in s: return s
    s = s.replace("apply plugin: 'com.android.application'", "apply plugin: 'com.android.application'\napply plugin: 'kotlin-android'", 1)
    return s.replace("android {", "android {\n    kotlinOptions { jvmTarget = '17' }", 1)
edit('app/build.gradle', app)

# Widget dùng API 26 trở lên
edit('variables.gradle', lambda s: re.sub(r"minSdkVersion\s*=\s*\d+", "minSdkVersion = 26", s))

# Khai báo quyền, widget và màn hình cài đặt
PERMS = '''    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
'''
WIDGET = '''
        <activity android:name=".ConfigActivity" android:exported="true"
            android:label="Cài đặt widget" android:theme="@android:style/Theme.DeviceDefault.Light">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_CONFIGURE" />
            </intent-filter>
        </activity>
        <receiver android:name=".ClockWidget" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/clock_widget_info" />
        </receiver>
'''
def man(s):
    if 'ClockWidget' in s: return s
    s = s.replace('<application', PERMS + '    <application', 1)
    return s.replace('</application>', WIDGET + '    </application>', 1)
edit('app/src/main/AndroidManifest.xml', man)
